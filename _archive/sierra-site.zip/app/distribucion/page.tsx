import data from '../data/siteData.json'

export const metadata = { title: 'Distribución — Sierra' }

export default function Page() {
  return (
    <main className="section">
      <div className="container">
        <h2>Distribución</h2>
        <ul className="list">
          {data.distribution.map((d, i) => <li key={i}>• {d}</li>)}
        </ul>
      </div>
    </main>
  )
}
