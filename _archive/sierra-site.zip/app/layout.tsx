import './globals.css'
import NavBar from './components/NavBar'
import Footer from './components/Footer'

export const metadata = {
  title: 'SIERRA — Documental (2025)',
  description: 'Un viaje profundo al corazón de las Sierras de Elizondo. Largometraje documental de Juan Francisco Montes.',
  metadataBase: new URL('https://example.com'),
  openGraph: {
    title: 'SIERRA — Documental (2025)',
    description: 'Un viaje profundo al corazón de las Sierras de Elizondo.',
    url: 'https://example.com',
    siteName: 'SIERRA',
    images: [{ url: '/og.jpg', width: 1200, height: 630 }],
    locale: 'es_AR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SIERRA — Documental (2025)',
    description: 'Un viaje profundo al corazón de las Sierras de Elizondo.',
    images: ['/og.jpg'],
  },
}

export default function RootLayout({ children }) {
  const ld = {
    '@context': 'https://schema.org',
    '@type': 'Movie',
    'name': 'Sierra',
    'alternateName': 'SIERRA — Documental (2025)',
    'genre': 'Documentary',
    'duration': 'PT75M',
    'inLanguage': 'es',
    'countryOfOrigin': 'AR',
    'director': { '@type': 'Person', 'name': 'Juan Francisco Montes' },
    'producer': { '@type': 'Person', 'name': 'Ciro Néstor Novelli' },
    'datePublished': '2025',
    'description': 'Largometraje documental sobre las Sierras de Elizondo y Ladislao Reyes Chávez.',
    'potentialAction': { '@type': 'WatchAction', 'target': 'https://youtu.be/D9eAYHrvDjc' }
  };
  return (
    <html lang="es">
      <body>
        <NavBar />
        {children}
        <Footer />
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify(ld)}} />
      </body>
    </html>
  )
}
