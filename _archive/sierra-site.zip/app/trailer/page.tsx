import YouTube from '../components/YouTube'

export const metadata = { title: 'Tráiler — Sierra' }

export default function Page() {
  return (
    <main className="section">
      <div className="container">
        <h2>Tráiler</h2>
        <YouTube id="D9eAYHrvDjc" />
        <p className="small">También disponible en YouTube.</p>
      </div>
    </main>
  )
}
