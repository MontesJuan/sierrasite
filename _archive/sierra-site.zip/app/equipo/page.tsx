import data from '../data/siteData.json'

export const metadata = { title: 'Equipo — Sierra' }

export default function Page() {
  return (
    <main className="section">
      <div className="container">
        <h2>Equipo técnico</h2>
        <ul className="list">
          {data.credits.map((c, i) => <li key={i}>• {c}</li>)}
        </ul>
      </div>
    </main>
  )
}
