import data from '../data/siteData.json'

export const metadata = { title: 'Contacto — Sierra' }

export default function Page() {
  const c = data.contact
  return (
    <main className="section">
      <div className="container">
        <h2>Contacto</h2>
        <p><strong>Instagram:</strong> {c.instagram}</p>
        <p><strong>Email:</strong> <a href={`mailto:${c.email}`}>{c.email}</a></p>
        <p><strong>Teléfono:</strong> {c.phone}</p>
        <div className="card" style={{marginTop:24}}>
          <h3>Documental completo (Vimeo)</h3>
          <p className="small">Contraseña: <kbd>SIERRA25</kbd></p>
          <p className="small">Link: https://vimeo.com/1087761692</p>
        </div>
      </div>
    </main>
  )
}
