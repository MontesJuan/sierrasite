export default function Footer() {
  return (
    <footer>
      <div className="container">
        <div style={{display:'flex', gap:24, flexWrap:'wrap'}}>
          <div style={{flex:1, minWidth:260}}>
            <div style={{fontWeight:700, letterSpacing:'.12em'}}>SIERRA</div>
            <p className="small">Largometraje documental (2025), 75 min. San Juan, Argentina.</p>
          </div>
          <div style={{flex:1, minWidth:260}}>
            <div>Contacto</div>
            <div className="small">
              <div>@sierra.docu</div>
              <div><a href="mailto:mulanimavisual@gmail.com">mulanimavisual@gmail.com</a></div>
              <div>+54 2645 101344</div>
            </div>
          </div>
        </div>
        <div className="small" style={{marginTop:16}}>© {new Date().getFullYear()} Sierra — Un documental de Juan Francisco Montes.</div>
      </div>
    </footer>
  )
}
