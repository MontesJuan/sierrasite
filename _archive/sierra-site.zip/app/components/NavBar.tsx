'use client'
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const links = [
  { href: '/', label: 'Inicio' },
  { href: '/sinopsis', label: 'Sinopsis' },
  { href: '/trailer', label: 'Tráiler' },
  { href: '/impacto', label: 'Impacto' },
  { href: '/equipo', label: 'Equipo' },
  { href: '/financiacion', label: 'Financiación' },
  { href: '/distribucion', label: 'Distribución' },
  { href: '/contacto', label: 'Contacto' },
];

export default function NavBar() {
  const pathname = usePathname();
  return (
    <nav>
      <Link className="logo" href="/">SIERRA</Link>
      {links.map(l => (
        <Link key={l.href} href={l.href} className={pathname === l.href ? 'active' : ''}>{l.label}</Link>
      ))}
      <div style={{marginLeft:'auto'}}>
        <a className="btn" href="https://youtu.be/D9eAYHrvDjc" target="_blank" rel="noreferrer">Ver tráiler</a>
      </div>
    </nav>
  )
}
