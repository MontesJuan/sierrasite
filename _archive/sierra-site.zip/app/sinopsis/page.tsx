import data from '../data/siteData.json'

export const metadata = { title: 'Sinopsis — Sierra' }

export default function Page() {
  return (
    <main className="section">
      <div className="container">
        <h2>Sinopsis</h2>
        <p style={{whiteSpace:'pre-wrap'}}>{data.synopsis}</p>
      </div>
    </main>
  )
}
