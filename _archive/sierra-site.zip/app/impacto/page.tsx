import data from '../data/siteData.json'

export const metadata = { title: 'Impacto — Sierra' }

export default function Page() {
  return (
    <main className="section">
      <div className="container">
        <h2>Impacto social y cultural</h2>
        <ul className="list">
          {data.impact.map((d, i) => <li key={i}>• {d}</li>)}
        </ul>
      </div>
    </main>
  )
}
