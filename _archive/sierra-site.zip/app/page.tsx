import data from './data/siteData.json'

export default function Page() {
  return (
    <main>
      <div className="hero">
        <div className="container">
          <h1>SIERRA</h1>
          <p>{data.tagline}</p>
          <p className="small">{data.runtime_lang_year}</p>
        </div>
      </div>

      <section className="section">
        <div className="container grid">
          <div className="card">
            <h2>Storyline</h2>
            <p>{data.logline}</p>
            <p className="small">¿El nuevo camino traerá progreso o transformará la identidad serrana?</p>
          </div>
          <div className="card">
            <h2>Estado actual</h2>
            <ul className="list">
              {data.distribution.map((d, i) => <li key={i}>• {d}</li>)}
            </ul>
          </div>
          <div className="card">
            <h2>Impacto social y cultural</h2>
            <ul className="list">
              {data.impact.map((d, i) => <li key={i}>• {d}</li>)}
            </ul>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <a className="btn" href="/trailer">Ver tráiler</a>{' '}
          <a className="btn" href="/financiacion">Colaborar / Patrocinar</a>{' '}
          <a className="btn" href="/contacto">Contacto</a>
        </div>
      </section>
    </main>
  )
}
