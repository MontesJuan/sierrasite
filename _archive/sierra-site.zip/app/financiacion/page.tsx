import data from '../data/siteData.json'

export const metadata = { title: 'Financiación y Patrocinio — Sierra' }

export default function Page() {
  const fin = data.financing
  return (
    <main className="section">
      <div className="container">
        <h2>Financiación y patrocinio</h2>
        <div className="grid">
          <div className="card">
            <h3>Resumen</h3>
            <ul className="list">
              <li>Inversión total: {fin.investment_total}</li>
              <li>{fin.incaa}</li>
              <li>{fin.director}</li>
            </ul>
            <p>{fin.goal}</p>
          </div>
          <div className="card">
            <h3>Cómo colaborar</h3>
            <ul className="list">
              {fin.sponsorship.map((s, i) => <li key={i}>• {s}</li>)}
            </ul>
          </div>
          <div className="card">
            <h3>Beneficios para sponsors</h3>
            <ul className="list">
              {fin.benefits.map((b, i) => <li key={i}>• {b}</li>)}
            </ul>
          </div>
        </div>
        <p style={{marginTop:16}}>¿Te interesa colaborar? <a href="/contacto">Escribinos</a>.</p>
      </div>
    </main>
  )
}
